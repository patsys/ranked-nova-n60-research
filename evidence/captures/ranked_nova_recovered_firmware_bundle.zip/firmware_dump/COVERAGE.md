# What has been recovered

Verified coverage is the complete **CPU-visible address range 0x00000000 to
0x0001ffff (128 KiB)**, read twice with identical results. This is not proof
that the chip has no additional memory outside that range.

Included:

- Full 128 KiB snapshot and independent verification copy.
- 8 KiB bootloader-region binary.
- Plaintext application-region binary at 0x2000, with extent inferred from
  the captured update image.
- Vector table, reset/startup listings, and raw linear Thumb disassembly.
- USB request/reply evidence, hashes, tools, and the current SQLite record.
- Demonstrated RAM-code execution and direct USB readback.
- Located bootloader crypto-control code and a hardware-assisted block path.

Not established or recovered:

- Exact MCU part number and complete peripheral documentation.
- A complete GPIO/key-matrix/LED pin map or a working QMK port.
- Original C source, full function reconstruction, or vendor build files.
- Complete RAM, OTP/fuse contents, or an identified encryption key/algorithm.
- A tested flash restore/programming procedure. The existing work is read-only
  with respect to flash; no erase/program test was performed.

The archive is an evidence/analysis bundle, **not an installable firmware
package**. Byte addresses and load bases are documented in README.md.
